public class Item {
    public Item(){}
    public void buyItem(){}
}
