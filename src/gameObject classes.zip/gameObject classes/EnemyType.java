package sample;

public enum EnemyType  {
Obstacle,
Ta,
Lab,
Professor;
}
