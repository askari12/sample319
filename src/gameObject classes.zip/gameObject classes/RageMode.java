package sample;
import javafx.scene.image.Image;

public class RageMode extends PowerUp {
    public RageMode(Location loc, Dimension dimensions, Movement movement, Image img){
        super(loc,dimensions,movement,img);
    }

    @Override
    public void powerUp(Location loc, Dimension dimensions, Movement movement, Image img) {

    }

    public void powers(){}

    @Override
    public void renderobject() {

    }

    @Override
    public void destroy() {

    }
}
