package sample;

public enum Student {
    Type_A,
    Type_B,
    Type_C;

}
