package sample;

import java.awt.*;

public class Controller {

    public void change() {
        System.out.println("jo");
    }
}
